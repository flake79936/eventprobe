<?php
	$config['callback_url'] = 'http://www.eventprobe.com/?fbTrue=true'; //?fbTrue=true is required.

	//Facebook configuration
	$config['App_ID']     = '861882643830735';
	$config['App_Secret'] = 'c7d8579a97d35848e7231a0291e476f6'; 
?>