<meta http-equiv="refresh" content="2; index.html">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
		<link href="favicon.ico" rel="shortcut icon"  />
		<title>Thank you!</title>
		
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="format-detection" content="telephone=no" />
		<meta name="format-detection" content="email=no" />
		
		<!--(Start) Style Sheets-->
			<link rel="STYLESHEET" type="text/css" href="css/fg_membersite.css">
			
			<!--(Start) Provided by JetDevLLC-->
				<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
				<link href="css/styleEdit.css"            rel="stylesheet" type="text/css" />
				<link href="css/responsiveEdit.css"       rel="stylesheet" type="text/css" />
				<!--[if IE 6]>
				<style type="text/css">img, div, { behavior: url("js/iepngfix.htc") }
				</style>
				<![endif]-->
			<!--(End) Provided by JetDevLLC-->
		<!--(End) Style Sheets-->
		
		<!--(Start) Scripts-->
			<script src="js/jsMethods.js"            type="text/javascript"></script>
			
			<!--(Start) Provided by JetDevLLC-->
				<script src="js/jquery-1.9.0.min.js" type="text/javascript"></script>
				<script src="js/iepngfix_tilebg.js"  type="text/javascript"></script>
				<script src="js/scrollTo.js"         type="text/javascript"></script>
				<script src="js/global.js"           type="text/javascript"></script>
			<!--(End) Provided by JetDevLLC-->
		<!--(End) Scripts-->
		
	</head>
	
	<body>
		<div class="header-wrap">
			<div class="header">
			</div><!--//header-->
		</div><!--//header-wrap-->

		<div class="mobile-menu-list">
		</div><!--//mobile-menu-list-->
	
		<div id='fg_membersite' align="center">
			<h2>Thanks for registering!</h2>
<!-- 
			Your confirmation email is on its way.
			Please click the link in the email to complete the registration.
 -->
		</div>
	</body>
</html>