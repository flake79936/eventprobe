$(document).ready(function() {
	$(function() {
		$( "#accordion" ).accordion({
			collapsible: true,
			heightStyle: "content",
			active: false,
		});
		$( "#accordion2" ).accordion({
			collapsible: true,
			heightStyle: "content",
			active: false,
		});
	});  
});





