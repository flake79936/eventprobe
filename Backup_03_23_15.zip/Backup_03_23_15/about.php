<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>

<?PHP require_once("./include/membersite_config.php"); ?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Eventprobe</title>
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link rel="stylesheet" media="all" href=""/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<!-- Adding "maximum-scale=1" fixes the Mobile Safari auto-zoom bug: http://filamentgroup.com/examples/iosScaleBug/ -->
        
        <!--STYLE-->
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/top.css" />
        <link rel="stylesheet" type="text/css" href="css/links.css" />
        <link rel="stylesheet" type="text/css" href="css/footer.css" />

        <!--FAVICON-->
        <link rel="shortcut icon" href="favicon.ico"  />
	</head>
	
	<body lang="en">
    	<div class="top">
			<?PHP include './top.php';?>
        </div>
        
        <div class="content">
			<h3>About Us</h3>
            <p>Everyone is working more and vacationing less these days. And getting away for a 3-day weekend is more common now than ever. Making the most of those 72 hours has become key. When you get there what are going to do? Where should you go? Is there a concert? Theres an app for that! Say hello to your friends at EventProbe. All events across the nation in the palm of your hand. Searchable by location, genre, time…you get the picture. No more fumbling through multiple sites.</p>
            <img src="images/about_events.png">
			<div class="clear"> </div>
            
        </div>
        
        <div class="links">
			<?PHP include './links.php'; ?>
        </div>
        
        <div class="footer">
			<?PHP include './footer.php'; ?>
        </div>
	</body>
</html>