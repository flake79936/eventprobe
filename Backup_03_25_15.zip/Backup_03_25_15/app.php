<!--Module-->

<link rel="stylesheet" type="text/css" href="css/twitter.css" />
<link rel="stylesheet" type="text/css" href="css/chart.css" />
<link rel="stylesheet" type="text/css" href="css/app.css" />

<script type="text/javascript" src="js/twitter.js"></script>

<div class="left">
	<!-- <div class="user"> -->
	<!-- <div class="box"> -->
	<br>
	<div id="example2"></div>
	<div class="clear"></div>
	<!-- 	</div> -->
	<div class="user">
		<div class="box"> </div>
		<div class="clear"></div>
	</div>
</div>
<div class="right">
<!-- <div class="advertisement"> -->
	<a href="http://www.rudolphchevrolet.com/" target="_blank"><img src="images/advertisement_01.jpg" alt="Banner"/></a>
	<a href="http://ravemarketing.com/" target="_blank"><img src="images/advertisement_02.jpg" alt="Banner" /></a>
<!-- </div> -->
	<div class="image">
		<!-- <img src="images/app.png" alt="Download App" /> -->
	</div>
		<!-- <div class="mobile"> </div> -->
	<div class="clear"></div>
</div>
<div class="clear"></div>


