This script is brought to you by Vasplus Programming Blog by whom all copy rights are reserved.


After you have openned the live_user_details_edit directory, do the following:



(1) Open the file named live_user_details_edit/database_connection.php and fill in your database connection settings

(2) Open the file named live_user_details_edit/TABLE.sql, copy the query to your server and
    run it to create the required table for this system

(3) Upload the directory named live_user_details_edit and its entire content to your server, location this directory through
    your web browser to see the system and you are done.



Have fun...